package com.cg.service;

import org.springframework.stereotype.Service;

import com.cg.bean.LoginBean;

@Service("loginService")
public class LoginService {
	
	
//	List<LoginBean>  loginDetails =  ArrayList<String>
	public String validateUser(LoginBean loginBean) {
		
		String userName = loginBean.getUserName();
		String password = loginBean.getPassword();
		
		if(userName.equals("Akshata") && password.equals("Abc@123")) {
			return "true";
		}
		else {
			return "false";
			
		}
	}
	
	
	public LoginBean displayLoginDetail(LoginBean loginBean) {
		System.out.println(loginBean);
		return loginBean;
	}
}
