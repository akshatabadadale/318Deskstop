package com.cg.service;

import com.cg.bean.CustomerBean;


public interface RegisterService {
	
	public CustomerBean init();
	
	public CustomerBean display(CustomerBean customer);
	
	public void  addCustomer(CustomerBean customer);
		
	public CustomerBean displayRegisterDetail(CustomerBean customer);
}
