package com.cg.service;

import org.springframework.stereotype.Service;

import com.cg.bean.CustomerBean;

@Service("registerService")
public class RegisterServiceImpl implements RegisterService{

	
	RegisterService service;
	
	public CustomerBean display(CustomerBean customer) {
		return customer;
	}

	
	public void addCustomer(CustomerBean customer) {
		System.out.println(customer);
		service.addCustomer(customer);
	}

	
	public CustomerBean init() {
		return new CustomerBean();
	}


	public CustomerBean displayRegisterDetail(CustomerBean customer) {
		return customer;
	}

}
